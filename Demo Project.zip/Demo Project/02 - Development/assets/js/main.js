
//create a two variables 

let menuBtn = document.getElementById("menuBtn");
let  sideNav = document.getElementById("sideNav")

sideNav.style.right = "-250px"

menuBtn.onclick = function(){

    if(sideNav.style.right == "-250px"){
        sideNav.style.right = "0"
    }else{
        sideNav.style.right = "-250px"
    }
}


// All animations will take exactly 500ms
var scroll = new SmoothScroll('a[href*="#"]', {
	speed: 500,
	speedAsDuration: true
});